import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS } from 'chart.js/auto';

const Dashboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchInteractionData = async () => {
      try {
        const response = await axios.get('/api/interactions/trends');
        setData(response.data);
      } catch (error) {
        console.error('Error fetching data', error);
      }
    };

    fetchInteractionData();
  }, []);

  const chartData = {
    labels: data.map(item => item.timestamp),
    datasets: [
      {
        label: 'Response Time (min)',
        data: data.map(item => item.responseTime),
        borderColor: 'rgba(75,192,192,1)',
        tension: 0.1,
      },
    ],
  };

  return (
    <div>
      <h2>Customer Interaction Trends</h2>
      <Line data={chartData} />
    </div>
  );
};

export default Dashboard;
