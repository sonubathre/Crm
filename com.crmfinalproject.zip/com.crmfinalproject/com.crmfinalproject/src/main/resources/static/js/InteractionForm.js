import React, { useState } from 'react';
import axios from 'axios';

const InteractionForm = () => {
  const [customerId, setCustomerId] = useState('');
  const [channel, setChannel] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newInteraction = { customerId, channel, content };
    try {
      await axios.post('/api/interactions', newInteraction);
      alert('Interaction created successfully');
    } catch (error) {
      console.error('Error creating interaction', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input 
        type="text" 
        placeholder="Customer ID" 
        value={customerId} 
        onChange={(e) => setCustomerId(e.target.value)} 
      />
      <input 
        type="text" 
        placeholder="Channel (email, phone, etc.)" 
        value={channel} 
        onChange={(e) => setChannel(e.target.value)} 
      />
      <textarea 
        placeholder="Content" 
        value={content} 
        onChange={(e) => setContent(e.target.value)} 
      />
      <button type="submit">Submit</button>
    </form>
  );
};

export default InteractionForm;
