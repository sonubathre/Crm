import React, { useState } from 'react';
import axios from 'axios';

const Search = () => {
  const [keyword, setKeyword] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    try {
      const response = await axios.get(`/api/interactions/search?keyword=${keyword}`);
      setResults(response.data);
    } catch (error) {
      console.error('Error searching interactions', error);
    }
  };

  return (
    <div>
      <h2>Search Interactions</h2>
      <input 
        type="text" 
        placeholder="Search by keyword" 
        value={keyword} 
        onChange={(e) => setKeyword(e.target.value)} 
      />
      <button onClick={handleSearch}>Search</button>
      <ul>
        {results.map((interaction) => (
          <li key={interaction.id}>{interaction.content}</li>
        ))}
      </ul>
    </div>
  );
};

export default Search;
