package com.crmfinalproject.dto;

import java.util.Date;
import java.util.List;

import com.crmfinalproject.entity.Customer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InteractionDTO {
		private long id;
		private long customerId;
	    private String  channel;
	    private String content;
	    @JsonFormat(shape = Shape.STRING,pattern = "dd-MM-yy")
	    private Date createdAt;
	    private String tags;
	    private String category;
	    private String priority;

}
