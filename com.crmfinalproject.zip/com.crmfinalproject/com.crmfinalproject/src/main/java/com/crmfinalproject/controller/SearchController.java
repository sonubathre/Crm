package com.crmfinalproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crmfinalproject.entity.Interaction;
import com.crmfinalproject.service.InteractionService;

@RestController
@RequestMapping("/api/search")
public class SearchController {
    @Autowired
    private InteractionService interactionService;

    @GetMapping
    public List<Interaction> searchInteractions(@RequestParam String keyword) {
        return interactionService.searchByKeyword(keyword);
    }
}

