package com.crmfinalproject.repository;

import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.Interaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface InteractionRepository extends JpaRepository<Interaction, Long> {

   
    List<Interaction> findByCustomerId(Long customerId);

    List<Interaction> findByCustomer(Customer customer);
    List<Interaction> findByChannelContainingIgnoreCase(String channel);
    List<Interaction> findByContentContainingIgnoreCase(String content);
    @Query("SELECT i FROM Interaction i WHERE FUNCTION('DATE_FORMAT', i.createdAt, '%Y-%m-%d') = :date")
    List<Interaction> findByCreatedAtDate(@Param("date") String date);
    List<Interaction> findByTagsContainingIgnoreCase(String tags);
    List<Interaction> findByCategoryContainingIgnoreCase(String category);
    List<Interaction> findByPriorityContainingIgnoreCase(String priority);
}

