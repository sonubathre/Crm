package com.crmfinalproject.controller;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crmfinalproject.dto.InteractionDTO;
import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.Interaction;
import com.crmfinalproject.entity.User;
import com.crmfinalproject.security.JwtHelper;
import com.crmfinalproject.service.CustomerService;
import com.crmfinalproject.service.InteractionService;
import com.crmfinalproject.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/interactions")
public class InteractionController {
    @Autowired
    private InteractionService interactionService;
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private CustomerService customerService;
    @Autowired
    private UserService userService;
    
    @Autowired
    private JwtHelper jwtHelper;
    
    
    @PostMapping
    public ResponseEntity<Interaction> addInteraction(@RequestBody InteractionDTO interactionDTO) {
    	Interaction interaction = modelMapper.map(interactionDTO, Interaction.class);
    	Customer customer = customerService.getCustomerById(interactionDTO.getCustomerId());
    	interaction.setCustomer(customer);
    	Interaction created = interactionService.saveInteraction(interaction);
    	return ResponseEntity.status(HttpStatus.CREATED).body(created); 
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Interaction>> getInteractionsByCustomer(@PathVariable Long customerId) {
    	List<Interaction> customerWiseInteraction =  interactionService.getInteractionsByCustomer(customerId);
    	return ResponseEntity.status(HttpStatus.OK).body(customerWiseInteraction);
    }
    @GetMapping
    public ResponseEntity<List<Interaction>> getAllInteractions()
    {
    	List<Interaction> allInteractions = interactionService.getAllInteractions();
    	return ResponseEntity.status(HttpStatus.OK).body(allInteractions);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Interaction> getInteractionById(@PathVariable long id)
    {
    	Interaction interaction = interactionService.getInteractionById(id);
    	return ResponseEntity.status(HttpStatus.OK).body(interaction);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteInteraction(@PathVariable long id)
    {
    	interactionService.deleteInteractionById(id);
    	return ResponseEntity.status(HttpStatus.NO_CONTENT).body("deleted successfully");
    }
    
    @GetMapping("/export")
    public ResponseEntity<byte[]> exportTasks(HttpServletRequest request) {
    	User user =null;
    	String token = null;
		String userName= null;
		String requestHeader = request.getHeader("Authorization");
		if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		user = userService.loadUserByUsername(userName);
    	
        ByteArrayOutputStream  outputStream = interactionService.exportInteractionToExcel();
        if (outputStream != null) {
            byte[] bytes = outputStream.toByteArray();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=Interaction.xlsx");
            return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/cust/{customerName}")
    public ResponseEntity<List<Interaction>> findByCustomer(@PathVariable String customerName)
    {
    	Customer customer = customerService.findByName(customerName);
    	return new ResponseEntity<>(interactionService.findByCustomer(customer),HttpStatus.OK);
    }
    @GetMapping("/channel/{channel}")
    public ResponseEntity<List<Interaction>> findByChannelContainingIgnoreCase(@PathVariable String channel)
    {
    	return new ResponseEntity<>(interactionService.findByChannelContainingIgnoreCase(channel),HttpStatus.OK);
    }
    
    @GetMapping("/content/{content}")
    public ResponseEntity<List<Interaction>> findByContentContainingIgnoreCase(@PathVariable String content)
    {
    	return new ResponseEntity<>(interactionService.findByContentContainingIgnoreCase(content),HttpStatus.OK);
    }
    
    @GetMapping("/createdDate/{date}")
    public ResponseEntity<List<Interaction>> findByCreatedAt(@PathVariable String date)
    {
    	return new ResponseEntity<>(interactionService.findByCreatedAt(date),HttpStatus.OK);
    }
    @GetMapping("/tags/{tags}")
    public ResponseEntity<List<Interaction>> findByTagsContainingIgnoreCase(@PathVariable String tags)
    {
    	return new ResponseEntity<>(interactionService.findByTagsContainingIgnoreCase(tags),HttpStatus.OK);
    }
    
    @GetMapping("/category/{category}")
    public ResponseEntity<List<Interaction>> findByCategoryContainingIgnoreCase(@PathVariable String category)
    {
    	return new ResponseEntity<>(interactionService.findByCategoryContainingIgnoreCase(category),HttpStatus.OK);
    }
    
    @GetMapping("/priority/{priority}")
    public ResponseEntity<List<Interaction>> findByPriorityContainingIgnoreCase(@PathVariable String priority)
    {
    	return new ResponseEntity<>(interactionService.findByPriorityContainingIgnoreCase(priority),HttpStatus.OK);
    }
    
}

