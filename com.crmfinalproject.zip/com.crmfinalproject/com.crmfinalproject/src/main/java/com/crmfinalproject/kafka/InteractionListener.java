package com.crmfinalproject.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.crmfinalproject.entity.Interaction;
import com.crmfinalproject.repository.InteractionRepository;

@Service
public class InteractionListener {

	@Autowired
	private InteractionRepository interactionRepository;
	
	@KafkaListener(topics = "interaction-queue",groupId = "interactionGroup")
	public void processInteraction(Interaction interaction) {
		System.out.println("Listener content=>"+interaction.getContent());

		if (interaction.getContent().toLowerCase().contains("error") ||
            interaction.getContent().toLowerCase().contains("problem")) {
            interaction.setCategory("COMPLAINT");
            interaction.setPriority("HIGH");
            
        } else if (interaction.getContent().toLowerCase().contains("suggest")) {
            interaction.setCategory("SUGGESTION");
            interaction.setPriority("MEDIUM");
        } else {
            interaction.setCategory("INFORMATION");
            interaction.setPriority("LOW");
        }
        
        interactionRepository.save(interaction);
    }
}
