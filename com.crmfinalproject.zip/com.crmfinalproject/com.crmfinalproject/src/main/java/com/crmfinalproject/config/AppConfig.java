package com.crmfinalproject.config;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.crmfinalproject.entity.User;
import com.crmfinalproject.repository.UserRepository;
import com.crmfinalproject.security.JwtAuthenticationFilter;


@Configuration
@EnableWebSecurity
public class AppConfig{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private CustomAccessDeniedHandler customAccessDeniedHandler;
	@Lazy
	@Autowired
	private JwtAuthenticationFilter filter;
	
	@Bean
	UserDetailsService userDetailsService()
	{
		return username -> {
            User users = userRepository.loadUserByUsername(username);
            System.out.println(users);
            if (users == null) {
                throw new UsernameNotFoundException("User not found with this username: " + username);
            }
		return (UserDetails) org.springframework.security.core.userdetails.User
				.withUsername(users.getUserName())
				.password(users.getPassword())
				.roles(users.getRole())
				.build();
		};
	}
	@Bean
	 SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		    http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login","/auth/login", "/register","/registerUser","/interactionPage","/dashboard","/WEB-INF/error/**","/error","/error/403","/WEB-INF/views/**").permitAll()
                .requestMatchers("/interactions").hasAnyRole("ADMIN","USER")
                .requestMatchers("/customers/**").hasRole("ADMIN")
                //.requestMatchers("/user/projects").hasRole("USER")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .failureHandler(authenticationFailureHandler())
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            ).exceptionHandling(exception -> exception.accessDeniedHandler(customAccessDeniedHandler))
            .sessionManagement(session ->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);
		    
		    return http.build();
		 
	    }
	
	@Bean
	 AuthenticationFailureHandler authenticationFailureHandler() {
	    SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
	    failureHandler.setDefaultFailureUrl("/login?error"); // Redirect to login page with error query param
	    return failureHandler;
	}
	
	@Bean
	PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	@Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration builder) throws Exception {
        return builder.getAuthenticationManager();
    }
	
	@Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }
}
