package com.crmfinalproject.service;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.Interaction;
import com.crmfinalproject.kafka.InteractionProducer;
import com.crmfinalproject.repository.InteractionRepository;





@Service
public class InteractionService {
    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private InteractionProducer interactionProducer;

    public Interaction saveInteraction(Interaction interaction) {
        interaction.setCreatedAt(new Date());
        Interaction savedInteraction =  interactionRepository.save(interaction);
        interactionProducer.sendInteractionForProcessing(savedInteraction);
        return savedInteraction;
    }

    public List<Interaction> getInteractionsByCustomer(Long customerId) {
        return interactionRepository.findByCustomerId(customerId);
    }
    
    public List<Interaction> searchByKeyword(String keyword) {
        return interactionRepository.findByContentContainingIgnoreCase(keyword);
    }
    
    public List<Interaction> getAllInteractions()
    {
    	return interactionRepository.findAll();
    }
    
    public Interaction getInteractionById(long id)
    {
    	return interactionRepository.findById(id).get();
    }
    
    public void deleteInteractionById(long id)
    {
    	 interactionRepository.deleteById(id);
    }

	public ByteArrayOutputStream exportInteractionToExcel() {
	    List<Interaction> allList = interactionRepository.findAll();

	    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        Sheet sheet = workbook.createSheet("Interaction");

	        // Create a title row
	        Font titleFont = workbook.createFont();
	        titleFont.setBold(true);
	        titleFont.setFontHeightInPoints((short) 16); // Set font size

	        CellStyle titleStyle = workbook.createCellStyle();
	        titleStyle.setFont(titleFont);
	        titleStyle.setAlignment(HorizontalAlignment.CENTER);
	        titleStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
	        titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row titleRow = sheet.createRow(0);
	        Cell titleCell = titleRow.createCell(0);
	        titleCell.setCellValue("Interaction List");
	        titleCell.setCellStyle(titleStyle);

	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 6)); // Merging title cells

	        // Create header row
	        Font headerFont = workbook.createFont();
	        headerFont.setColor(IndexedColors.WHITE.getIndex());
	        headerFont.setBold(true);

	        CellStyle headerStyle = workbook.createCellStyle();
	        headerStyle.setFont(headerFont);
	        headerStyle.setFillForegroundColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        CellStyle dataStyle = workbook.createCellStyle();
	        dataStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        dataStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row headerRow = sheet.createRow(1);
	        String[] headers = {"Customer Name", "Channel", "Content", "Created Date", "Tags", "Category","Priority"};
	        for (int i = 0; i < headers.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers[i]);
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, 20 * 256); // Set column width
	        }

	        // Populate data
	        int rowIndex = 2; // Starting row for data
	        for (Interaction interaction : allList) {
	            Row row = sheet.createRow(rowIndex++);

	            row.createCell(0).setCellValue(interaction.getCustomer().getName());
	            row.createCell(1).setCellValue(interaction.getChannel());
	            row.createCell(2).setCellValue(interaction.getContent());
	            row.createCell(3).setCellValue(interaction.getCreatedAt().toString().substring(0,10));
	            row.createCell(4).setCellValue(interaction.getTags());
	            row.createCell(5).setCellValue(interaction.getCategory());
	            row.createCell(6).setCellValue(interaction.getPriority());

	            // Apply data style to all cells in the row
	            for (int i = 0; i < headers.length; i++) {
	                row.getCell(i).setCellStyle(dataStyle);
	            }
	        }

	        workbook.write(outputStream);
	        return outputStream;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	
    public Map<String, Long> getCategoryWiseData() {
        List<Interaction> interactions = interactionRepository.findAll();
        return interactions.stream()
                .collect(Collectors.groupingBy(interaction -> interaction.getCategory().toString(), Collectors.counting()));
    }
    public Map<String, Long> getPriorityWiseData() {
        List<Interaction> interactions = interactionRepository.findAll();
        return interactions.stream()
                .collect(Collectors.groupingBy(interaction -> interaction.getPriority().toString(), Collectors.counting()));
    }
    
    public List<Interaction> findByCustomer(Customer customer){
    	return interactionRepository.findByCustomer(customer);
    }
    public List<Interaction> findByChannelContainingIgnoreCase(String channel){
    	return interactionRepository.findByChannelContainingIgnoreCase(channel);
    }
    public List<Interaction> findByContentContainingIgnoreCase(String content){
    	return interactionRepository.findByContentContainingIgnoreCase(content);
    }
    public List<Interaction> findByCreatedAt(String createdAt){
    	return interactionRepository.findByCreatedAtDate(createdAt);
    }
    public List<Interaction> findByTagsContainingIgnoreCase(String tags){
    	return interactionRepository.findByTagsContainingIgnoreCase(tags);
    }
    public List<Interaction> findByCategoryContainingIgnoreCase(String category){
    	return interactionRepository.findByCategoryContainingIgnoreCase(category);
    }
    public List<Interaction> findByPriorityContainingIgnoreCase(String priority){
    	return interactionRepository.findByPriorityContainingIgnoreCase(priority);
    }
}
