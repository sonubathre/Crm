package com.crmfinalproject.service;
import java.io.ByteArrayOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.Interaction;
import com.crmfinalproject.repository.CustomerRepository;

@Service
public class CustomerService 
{

	@Autowired
    private CustomerRepository customerRepository;
	
	public Customer createCustomer(Customer customer)
	{
		return customerRepository.save(customer);
	}
	
	public Customer updateCustomer(long id,Customer customer)
	{
		Customer updateCustomer = customerRepository.findById(id).orElseThrow(()-> new RuntimeException("Customer not found for Id : "+id));
		updateCustomer  = customerRepository.save(updateCustomer);
		return updateCustomer;
	}
	
	public Customer getCustomerById(long id)
	{
		Customer customer = customerRepository.findById(id).orElseThrow(()-> new RuntimeException("Customer not found for Id : "+id));
		return customer;
	}
	
	public List<Customer> getAllCustomers()
	{
		return customerRepository.findAll();
	}
	public void deleteCustomer(long id)
	{
		customerRepository.deleteById(id);
	}
	
	public ByteArrayOutputStream exportCustomerToExcel() {
	    List<Customer> allList = customerRepository.findAll();

	    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        Sheet sheet = workbook.createSheet("Customer");

	        // Create a title row
	        Font titleFont = workbook.createFont();
	        titleFont.setBold(true);
	        titleFont.setFontHeightInPoints((short) 16); // Set font size

	        CellStyle titleStyle = workbook.createCellStyle();
	        titleStyle.setFont(titleFont);
	        titleStyle.setAlignment(HorizontalAlignment.CENTER);
	        titleStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
	        titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row titleRow = sheet.createRow(0);
	        Cell titleCell = titleRow.createCell(0);
	        titleCell.setCellValue("Customer List");
	        titleCell.setCellStyle(titleStyle);

	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 3)); // Merging title cells

	        // Create header row
	        Font headerFont = workbook.createFont();
	        headerFont.setColor(IndexedColors.WHITE.getIndex());
	        headerFont.setBold(true);

	        CellStyle headerStyle = workbook.createCellStyle();
	        headerStyle.setFont(headerFont);
	        headerStyle.setFillForegroundColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        CellStyle dataStyle = workbook.createCellStyle();
	        dataStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        dataStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        Row headerRow = sheet.createRow(1);
	        String[] headers = {"Customer Name", "Email", "Phone", "Created Date"};
	        for (int i = 0; i < headers.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers[i]);
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, 20 * 256); // Set column width
	        }

	        // Populate data
	        int rowIndex = 2; // Starting row for data
	        for (Customer customer : allList) {
	            Row row = sheet.createRow(rowIndex++);

	            row.createCell(0).setCellValue(customer.getName());
	            row.createCell(1).setCellValue(customer.getEmail());
	            row.createCell(2).setCellValue(customer.getPhone());
	            row.createCell(3).setCellValue(customer.getCreatedAt().toString().substring(0,10));
	            
	            // Apply data style to all cells in the row
	            for (int i = 0; i < headers.length; i++) {
	                row.getCell(i).setCellStyle(dataStyle);
	            }
	        }

	        workbook.write(outputStream);
	        return outputStream;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}

	public List<Customer> searchByCustomerName(String name)
	{
		return customerRepository.findByNameContaining(name);
	}
	public List<Customer> searchByEmail(String email)
	{
		return customerRepository.findByEmailContaining(email);
	}
	public List<Customer> searchByPhone(String phone)
	{
		return customerRepository.findByPhoneContaining(phone);
	}
	public Customer findByName(String name)
	{
		return customerRepository.findByName(name);
	}
	
}

