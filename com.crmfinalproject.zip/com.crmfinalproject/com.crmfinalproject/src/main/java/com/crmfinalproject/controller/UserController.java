package com.crmfinalproject.controller;

import java.io.IOException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.crmfinalproject.entity.User;
import com.crmfinalproject.security.JwtHelper;
import com.crmfinalproject.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private JwtHelper jwtHelper;
	
	
	
	@GetMapping("/login")
	public String login(Model model)
	{
		model.addAttribute("title","CRM || Login");
		return "login";
	}
	@GetMapping("/register")
	public String register(Model model)
	{
		model.addAttribute("title","CRM || Register");
		return "register";
	}
	
	
	@PostMapping("/auth/login")
	public ResponseEntity<String> loginAuth(@RequestBody User user)
	{
		try {
            if (user.getUserName() == null || user.getUserName().trim().isEmpty() ||
                user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                return new ResponseEntity<>("Username and password cannot be blank", HttpStatus.BAD_REQUEST);
            }
            
            this.doAuthenticate(user.getUserName(), user.getPassword());
            UserDetails userDetails = userDetailsService.loadUserByUsername(user.getUserName());
            String token = jwtHelper.generateToken(userDetails);
            System.out.println("token::::"+token);
            return new ResponseEntity<>(token, HttpStatus.OK);
        } catch (BadCredentialsException e) {
            return new ResponseEntity<>("Invalid Username or Password", HttpStatus.UNAUTHORIZED);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
		
	}
	
	private void doAuthenticate(String userName, String password) {

        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userName, password);
        try 
        {
            authenticationManager.authenticate(authentication);
        } 
        catch (BadCredentialsException e) 
        {
            throw new BadCredentialsException(" Invalid Username or Password  !!");
        }

    }
	
	@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute User user,Model model)
	{
		User existUser =null;
		if(user !=null)
		{
			existUser = userService.loadUserByUsername(user.getUserName());
		}
		String erorMsg="";
		boolean errorFlag=false;
		if(user.getUserName().equals("") || user.getUserName() == null)
		{
			erorMsg+="<li>Please enter UserName</li>";
			errorFlag=true;
			
		}
		if(user.getPassword().equals("") || user.getPassword() == null)
		{
			erorMsg+="<li>Please enter Password</li>";
			errorFlag=true;
		}
		if(user.getRole().equals("Select") || user.getRole()==null)
		{
			erorMsg+="<li>Please select atleast one Roles.</li>";
			errorFlag=true;
		}
		if(existUser!=null && existUser.getUserName().equalsIgnoreCase(user.getUserName()))
		{
			erorMsg+="<li>UserName already exist.</li>";
			errorFlag = true;
		}
		if(errorFlag)
		{
			model.addAttribute("error", erorMsg);
			model.addAttribute("user", user);
			return "register";
		}
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		userService.registerUser(user);
		return "redirect:/login?success";
	}
	
	@GetMapping("/dashboard")
	public String showDashboard(@RequestParam("Authorization") String token,Model model,HttpServletRequest request) throws IOException
	{
		String decodedToken = new String(Base64.getDecoder().decode(token));
		
		System.out.println("dashboard:::::token :: "+decodedToken);
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		System.out.println("userName::::::"+userName);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			System.out.println("token validated");
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("USER") ? "User Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	
		 	
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	if(user.getRole().equals("ADMIN"))
		 	{
		 		    
		        model.addAttribute("title","CRM || Admin Dashboard");
		        
		 		return "dashboard";
		 	}
		 	else if(user.getRole().equals("USER"))
		 	{
		 		 model.addAttribute("title","CRM || User Dashboard");
		 		return "userDashboard";
		 	}
		}
		
		return "redirect:/login";
		 
		
	}
//	
//	@GetMapping("/user/projects")
//	public ResponseEntity<List<ProjectDTO>>  findProjectsAssignedToUser(HttpServletRequest request)
//	{
//		User user =null;
//		List<ProjectDTO> list =null;
//		try {
//			String token = null;
//			String userName= null;
//			String requestHeader = request.getHeader("Authorization");
//			if (requestHeader != null && requestHeader.startsWith("Bearer")) 
//	        {
//	            token = requestHeader.substring(7);
//	        }
//			 userName = jwtHelper.getUsernameFromToken(token);
//			user = userService.loadUserByUsername(userName);
//			list = projectService.findProjectsAssignedToUser(user.getId());
//			System.out.println("user project List======"+list);
//			
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return ResponseEntity.ok(list);
//		
//	}
//
//	@GetMapping("/user/tasks")
//	public ResponseEntity<List<TaskDTO>>  findTasksAssignedToUser(HttpServletRequest request)
//	{
//		User user =null;
//		List<TaskDTO> list =null;
//		try {
//			String token = null;
//			String userName= null;
//			String requestHeader = request.getHeader("Authorization");
//			if (requestHeader != null && requestHeader.startsWith("Bearer")) 
//	        {
//	            token = requestHeader.substring(7);
//	        }
//			 userName = jwtHelper.getUsernameFromToken(token);
//			user = userService.loadUserByUsername(userName);
//			list = taskService.findTasksAssignedToUser(user.getId());
//			System.out.println("user project List======"+list);
//			
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return ResponseEntity.ok(list);
//		
//	}
//	
//	@PatchMapping("/user/tasks")
//    public ResponseEntity<Void> updateStatus(@RequestBody TaskDTO taskDTO) {
//        taskService.updateTaskStatus(taskDTO);
//        return new ResponseEntity<>(HttpStatus.OK);
//    }
//	
//	@GetMapping("/user/projects/{projectID}")
//	public ResponseEntity<Project> getProjectByID(@PathVariable long projectID)
//	{
//		Project list = projectService.project(projectID);
//		return ResponseEntity.status(HttpStatus.OK).body(list);
//	}

}
