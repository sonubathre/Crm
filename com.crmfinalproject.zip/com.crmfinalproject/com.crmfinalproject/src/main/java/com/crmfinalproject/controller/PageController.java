package com.crmfinalproject.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.User;
import com.crmfinalproject.security.JwtHelper;
import com.crmfinalproject.service.CustomerService;
import com.crmfinalproject.service.InteractionService;
import com.crmfinalproject.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PageController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private InteractionService interactionService;

	
	@GetMapping("/interactionPage")
	public String showDashboard(@RequestParam("Authorization") String token,Model model,HttpServletRequest request) throws IOException
	{
		String decodedToken = new String(Base64.getDecoder().decode(token));
		
		System.out.println("dashboard:::::token :: "+decodedToken);
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		System.out.println("userName::::::"+userName);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			System.out.println("token validated");
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("USER") ? "User Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	if(user.getRole().equals("ADMIN")) {
			 	List<Customer> customerList = customerService.getAllCustomers();
			 	model.addAttribute("customerList",customerList);
			 	 model.addAttribute("title","CRM || Interaction List");
			 	 
		 	 	Map<String, Long> categoryWiseData = interactionService.getCategoryWiseData();
		        ObjectMapper objectMapper1 = new ObjectMapper();
		        String categoryWiseDataJson = objectMapper1.writeValueAsString(categoryWiseData);
		        model.addAttribute("categoryWiseData", categoryWiseDataJson);
		        
		        Map<String, Long> priorityWiseData = interactionService.getPriorityWiseData();
		        ObjectMapper objectMapper2 = new ObjectMapper();
		        String priorityWiseDataJson = objectMapper2.writeValueAsString(priorityWiseData);
		        model.addAttribute("priorityWiseData", priorityWiseDataJson);
			 	 
			 	return "interactionList";
		 	}else if(user.getRole().equals("USER")) {
		 		 model.addAttribute("title","CRM || Interaction List");
		 		return "interactionList";
		 	}
		 		
		}
		
		return "redirect:/login";
		 
		
	}

}
