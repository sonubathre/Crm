package com.crmfinalproject.controller;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crmfinalproject.entity.Customer;
import com.crmfinalproject.entity.User;
import com.crmfinalproject.security.JwtHelper;
import com.crmfinalproject.service.CustomerService;
import com.crmfinalproject.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/customers")
public class CustomerController {
    
	@Autowired
    private CustomerService customerService;
	
	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private UserService userService;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        Customer created =  customerService.createCustomer(customer);
        return new ResponseEntity<>(created,HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomer(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        return new ResponseEntity<>(customer,HttpStatus.OK);
    }
    
    @PutMapping
    public ResponseEntity<Customer> updateCustomer(@PathVariable long id,@RequestBody Customer customer)
    {
    	Customer updated= customerService.updateCustomer(id, customer);
    	return new ResponseEntity<>(updated,HttpStatus.OK);
    }
    
    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomer()
    {
    	List<Customer> allCustomer = customerService.getAllCustomers();
    	return new ResponseEntity<>(allCustomer,HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable long id)
    {
    	customerService.deleteCustomer(id);
    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping("/export")
    public ResponseEntity<byte[]> exportTasks(HttpServletRequest request) {
    	User user =null;
    	String token = null;
		String userName= null;
		String requestHeader = request.getHeader("Authorization");
		if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		user = userService.loadUserByUsername(userName);
    	
        ByteArrayOutputStream  outputStream = customerService.exportCustomerToExcel();
        if (outputStream != null) {
            byte[] bytes = outputStream.toByteArray();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=Customer.xlsx");
            return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/name/{name}")
    public ResponseEntity<List<Customer>> searchByCustomerName(@PathVariable String name)
    {
    	return ResponseEntity.status(HttpStatus.OK).body(customerService.searchByCustomerName(name));
    }
    
    @GetMapping("/email/{email}")
    public ResponseEntity<List<Customer>> searchByCustomerEmail(@PathVariable String email)
    {
    	return ResponseEntity.status(HttpStatus.OK).body(customerService.searchByEmail(email));
    }
    
    @GetMapping("/phone/{phone}")
    public ResponseEntity<List<Customer>> searchByCustomerPhone(@PathVariable String phone)
    {
    	return ResponseEntity.status(HttpStatus.OK).body(customerService.searchByPhone(phone));
    }
    
    
}

