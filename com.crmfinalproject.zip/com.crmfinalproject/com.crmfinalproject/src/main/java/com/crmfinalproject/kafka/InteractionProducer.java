package com.crmfinalproject.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.crmfinalproject.entity.Interaction;

@Service
public class InteractionProducer {

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;
	
	public void sendInteractionForProcessing(Interaction interaction) {
		System.out.println("producer content=>"+interaction.getContent());
		this.kafkaTemplate.send("interaction-queue", interaction);   
    }
}
