package com.crmfinalproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crmfinalproject.entity.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	
	List<Customer> findByNameContaining(String name);
	
	List<Customer> findByPhoneContaining(String phone);
	
	List<Customer> findByEmailContaining(String email);
	
	Customer findByName(String name);
   
}
